# Copyright 2022 netease. All rights reserved.
# Author zhaochaochao@corp.netease.com
# Date   2022/9/13
# Brief
from . import gpu_mem_mgr

__all__ = ['gpu_mem_mgr']
