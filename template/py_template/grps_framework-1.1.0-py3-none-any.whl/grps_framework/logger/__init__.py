# Copyright 2022 netease. All rights reserved.
# Author zhaochaochao@corp.netease.com
# Date   2023/8/31
# Brief
from . import logger

__all__ = ['logger']
